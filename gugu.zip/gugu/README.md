# covid19_prj"# yu_j" 
"# yu_j"  git init git add README.md git commit -m "first commit" git branch -M main git remote add origin https://github.com/21yuyu99/yu_j.git git push -u origin main
